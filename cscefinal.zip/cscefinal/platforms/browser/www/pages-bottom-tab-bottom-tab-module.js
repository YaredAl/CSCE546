(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-bottom-tab-bottom-tab-module"],{

/***/ "X24O":
/*!*******************************************************!*\
  !*** ./src/app/pages/bottom-tab/bottom-tab.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJib3R0b20tdGFiLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "kFHx":
/*!*******************************************************!*\
  !*** ./src/app/pages/bottom-tab/bottom-tab.module.ts ***!
  \*******************************************************/
/*! exports provided: BottomTabPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BottomTabPageModule", function() { return BottomTabPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _bottom_tab_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./bottom-tab-routing.module */ "mR3p");
/* harmony import */ var _bottom_tab_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./bottom-tab.page */ "zbLD");







let BottomTabPageModule = class BottomTabPageModule {
};
BottomTabPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _bottom_tab_routing_module__WEBPACK_IMPORTED_MODULE_5__["BottomTabPageRoutingModule"]
        ],
        declarations: [_bottom_tab_page__WEBPACK_IMPORTED_MODULE_6__["BottomTabPage"]]
    })
], BottomTabPageModule);



/***/ }),

/***/ "mR3p":
/*!***************************************************************!*\
  !*** ./src/app/pages/bottom-tab/bottom-tab-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: BottomTabPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BottomTabPageRoutingModule", function() { return BottomTabPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _bottom_tab_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./bottom-tab.page */ "zbLD");




const routes = [
    {
        path: '',
        component: _bottom_tab_page__WEBPACK_IMPORTED_MODULE_3__["BottomTabPage"],
        children: [
            { path: '', redirectTo: 'chats', pathMatch: 'full' },
            {
                path: 'chats',
                loadChildren: () => Promise.all(/*! import() | chats-chats-module */[__webpack_require__.e("common"), __webpack_require__.e("chats-chats-module")]).then(__webpack_require__.bind(null, /*! ../chats/chats.module */ "UTXh")).then(m => m.ChatsPageModule)
            },
            {
                path: 'groups',
                loadChildren: () => Promise.all(/*! import() | groups-groups-module */[__webpack_require__.e("common"), __webpack_require__.e("groups-groups-module")]).then(__webpack_require__.bind(null, /*! ../groups/groups.module */ "ak9z")).then(m => m.GroupsPageModule)
            },
            {
                path: 'profile',
                loadChildren: () => Promise.all(/*! import() | profile-profile-module */[__webpack_require__.e("common"), __webpack_require__.e("profile-profile-module")]).then(__webpack_require__.bind(null, /*! ../profile/profile.module */ "723k")).then(m => m.ProfilePageModule)
            },
        ]
    }
];
let BottomTabPageRoutingModule = class BottomTabPageRoutingModule {
};
BottomTabPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], BottomTabPageRoutingModule);



/***/ }),

/***/ "td30":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/bottom-tab/bottom-tab.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-tabs>\n  <ion-tab-bar slot=\"bottom\">\n    <ion-tab-button tab=\"chats\">\n      <ion-icon name=\"chatbubbles-outline\"></ion-icon>\n      <ion-label>Chats</ion-label>\n    </ion-tab-button>\n    <ion-tab-button tab=\"groups\">\n      <ion-icon name=\"people-circle-outline\"></ion-icon>\n      <ion-label>Groups</ion-label>\n    </ion-tab-button>\n    <ion-tab-button tab=\"profile\">\n      <ion-icon name=\"person-outline\"></ion-icon>\n      <ion-label>Profile</ion-label>\n    </ion-tab-button>\n  </ion-tab-bar>\n</ion-tabs>");

/***/ }),

/***/ "zbLD":
/*!*****************************************************!*\
  !*** ./src/app/pages/bottom-tab/bottom-tab.page.ts ***!
  \*****************************************************/
/*! exports provided: BottomTabPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BottomTabPage", function() { return BottomTabPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_bottom_tab_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./bottom-tab.page.html */ "td30");
/* harmony import */ var _bottom_tab_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./bottom-tab.page.scss */ "X24O");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let BottomTabPage = class BottomTabPage {
    constructor() { }
    ngOnInit() {
    }
};
BottomTabPage.ctorParameters = () => [];
BottomTabPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-bottom-tab',
        template: _raw_loader_bottom_tab_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_bottom_tab_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], BottomTabPage);



/***/ })

}]);
//# sourceMappingURL=pages-bottom-tab-bottom-tab-module.js.map