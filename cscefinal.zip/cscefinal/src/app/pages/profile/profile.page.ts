import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as firebase from 'firebase';
import { ComponentService } from 'src/app/services/component.service';
import { ActionSheetController, NavController } from '@ionic/angular';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {

  profileForm: FormGroup;
  profileFormSubmitted = false;
  db = firebase.default.firestore();
  picture = '';
  image: any;
  userData = JSON.parse(localStorage.getItem('userData'));

  constructor(private formBuilder: FormBuilder, private componentService: ComponentService, private actionSheetController: ActionSheetController,
    private camera: Camera, private navCtrl: NavController) {
    this.picture = this.userData.picture;
  }

  getImage(type: any, from: any) {
    if (from == 'gallery') {
      var options: CameraOptions = {
        quality: 100,
        allowEdit: true,
        targetWidth: 146,
        targetHeight: 136,
        saveToPhotoAlbum: false,
        destinationType: this.camera.DestinationType.DATA_URL,
        sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
        encodingType: this.camera.EncodingType.JPEG,
      }
    } else {
      var options: CameraOptions = {
        quality: 100,
        allowEdit: true,
        targetWidth: 146,
        targetHeight: 136,
        saveToPhotoAlbum: false,
        destinationType: this.camera.DestinationType.DATA_URL,
        encodingType: this.camera.EncodingType.JPEG,
        mediaType: this.camera.MediaType.PICTURE
      }
    }

    this.camera.getPicture(options).then(
      (imageData) => {
        const image = 'data:image/jpeg;base64,' + imageData;
        this.picture = image;
        this.image = image;
      }, (err) => {
        console.log(err);
      }
    );
  }

  async onImage() {
    const sheet = await this.actionSheetController.create({
      header: 'Select Option',
      buttons: [{
        text: 'Camera',
        icon: 'camera',
        handler: () => {
          this.getImage(this.camera.PictureSourceType.CAMERA, 'camera');
        }
      }, {
        text: 'Gallery',
        icon: 'images',
        handler: () => {
          this.getImage(this.camera.PictureSourceType.PHOTOLIBRARY, 'gallery');
        }
      }, {
        text: 'Cancel',
        icon: 'close',
        role: 'cancel',
        handler: () => {
        }
      }]
    });
    return sheet.present();
  }

  onPicChange(event: any) {
    const type: string = event.target.files[0].type.toString();
    if (type.search('image') === 0) {
      this.picture = 'image';
      if (event.target.files && event.target.files[0]) {
        const reader = new FileReader();
        reader.readAsDataURL(event.target.files[0]);
        reader.onload = (ev: any) => {
          this.picture = ev.target.result;
        };
      }
    }
    this.image = event.target.files[0];
  }

  onSubmitClick() {
    this.profileFormSubmitted = true;
    if (this.profileForm.valid) {
      this.componentService.getLoader().then(
        (loader) => {
          loader.present().then(
            () => {
              if (this.image) {
                const obj = this;
                const fileName = this.userData.number;
                const fileRef = firebase.default.storage().ref('images/' + fileName);
                const uploadTask = fileRef.putString(this.image);
                return new Promise(
                  (resolve, reject) => {
                    uploadTask.on('state_changed', snapshot => {
                    }, error => {
                      reject(error);
                    }, () => {
                      uploadTask.snapshot.ref.getDownloadURL().then(function (downloadURL) {
                        obj.db.collection('testUsers').where('number', '==', this.userData.number).get().then(function (res) {
                          res.forEach(function (user) {
                            obj.db.collection('testUsers').doc(user.id).update({
                              name: obj.profileForm.value.name,
                              picture: downloadURL,
                              updated_at: new Date().toISOString()
                            });
                          });
                          obj.userData.name = obj.profileForm.value.name;
                          obj.userData.picture = downloadURL;
                          localStorage.setItem('userData', JSON.stringify(obj.userData));
                        });
                        resolve({ fileName, downloadURL });
                        obj.componentService.getToast('Profile updated successfully.', 2000, 'top').then(
                          (toast) => {
                            toast.present();
                          }
                        );
                        loader.dismiss();
                      });
                    });
                  }
                );
              } else {
                const obj = this;
                this.db.collection('testUsers').where('number', '==', this.userData.number).get().then(function (res) {
                  res.forEach(function (user) {
                    obj.db.collection('testUsers').doc(user.id).update({
                      name: obj.profileForm.value.name,
                      updated_at: new Date().toISOString()
                    });
                  });
                });
                obj.userData.name = obj.profileForm.value.name;
                localStorage.setItem('userData', JSON.stringify(obj.userData));
                this.componentService.getToast('Profile updated successfully.', 2000, 'top').then(
                  (toast) => {
                    toast.present();
                  }
                );
                loader.dismiss();
              }
            }
          );
        }
      );
    }
  }

  onLogOutClick() {
    localStorage.clear();
    this.navCtrl.navigateRoot('/login');
  }

  ionViewDidEnter() {
    this.profileForm = this.formBuilder.group({
      name: [this.userData.name, Validators.required],
      number: [this.userData.number],
    });
  }

  ngOnInit() {
    this.profileForm = this.formBuilder.group({
      name: ['', Validators.required],
      number: ['']
    });
  }

}