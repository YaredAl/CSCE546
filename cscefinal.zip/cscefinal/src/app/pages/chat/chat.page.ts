import { Location } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IonContent } from '@ionic/angular';
import * as firebase from 'firebase';
import { ApiService } from 'src/app/services/api.service';
import { ComponentService } from 'src/app/services/component.service';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.page.html',
  styleUrls: ['./chat.page.scss'],
})
export class ChatPage implements OnInit {

  @ViewChild('scrollElement', { static: false }) content: IonContent;
  chats: any[] = [];
  db = firebase.default.firestore();
  messageRoom: any = '';
  refMessages: any = '';
  message: any = '';
  title: any = '';
  msgField = false;
  userData = JSON.parse(localStorage.getItem('userData'));
  recievers = [];

  constructor(public route: ActivatedRoute, private componentService: ComponentService, private apiService: ApiService, private location: Location) {
    this.messageRoom = route.snapshot.queryParams.data.chatroom;
    if (route.snapshot.queryParams.data.group_name) {
      this.title = route.snapshot.queryParams.data.group_name;
      this.recievers = route.snapshot.queryParams.data.created_with;
    } else {
      this.title = route.snapshot.queryParams.data.chat_name;
    }
    this.refMessages = this.db.collection('messages').doc(this.messageRoom);
  }

  onBackClick() {
    this.location.back();
  }

  sendNotification(token, title, message, from) {
    this.apiService.sendNotification(token, title, message, from).subscribe(
      (res: any) => { }, (err: any) => { }
    );
  }

  onAddClick() {
    this.componentService.getUserAlert('Enter Number').then(
      (alrt) => {
        alrt.present();
        alrt.onDidDismiss().then(
          (res: any) => {
            if (res.role == 'true') {
              if (res.data.values.number) {
                const obj = this;
                this.db.collection('testUsers').where('number', '==', res.data.values.number).get().then(function (response) {
                  if (response.docChanges().length > 0) {
                    response.forEach(function (doc) {
                      obj.componentService.getLoader().then(
                        (loader) => {
                          loader.present().then(
                            () => {
                              let id: any;
                              let users = [{ number: doc.data().number, token: doc.data().token }];
                              obj.db.collection('groups').where('chatroom', '==', obj.messageRoom).get().then(function (res) {
                                res.forEach(function (doc) {
                                  id = doc.id;
                                  users.push(...doc.data().created_with);
                                });
                                obj.recievers = users;
                                obj.db.collection('groups').doc(id).set({
                                  created_with: users
                                }, { merge: true });
                                obj.componentService.getToast('User added.', 2000, 'top').then(
                                  (toast) => {
                                    toast.present();
                                  }
                                );
                                loader.dismiss();
                              });
                            }
                          );
                        }
                      );
                    });
                  } else {
                    obj.componentService.getToast('User not exist.', 2000, 'top').then(
                      (toast) => {
                        toast.present();
                      }
                    );
                  }
                });
              } else {
                this.componentService.getToast('Enter number.', 2000, 'top').then(
                  (toast) => {
                    toast.present();
                  }
                );
              }
            }
          }
        );
      }
    );
  }

  onMessage() {
    if (this.message.trim() != '') {
      this.refMessages.collection(this.messageRoom).add({
        message: this.message,
        sender_id: this.userData.number,
        created_at: new Date().toISOString()
      });
      if (this.recievers.length > 0) {
        this.recievers.forEach((user) => {
          this.sendNotification(user.token, this.userData.number, this.message, this.userData.number);
        });
      } else {
        this.sendNotification(this.route.snapshot.queryParams.data.created_with_token, this.userData.number, this.message, this.userData.number);
      }
      this.msgField = false;
      this.message = '';
      this.content.scrollByPoint(0, 100000000, 300);
    } else {
      this.componentService.getToast('Cannot send empty message.', 2000, 'top').then(
        (toast) => {
          toast.present();
        }
      );
    }
  }

  onMessageField() {
    if (this.message.trim() == '') {
      this.msgField = false;
    } else {
      this.msgField = true;
    }
  }

  getChats(chatroom) {
    const obj = this;
    let sms = [];
    let counter = 1;
    obj.refMessages.collection(chatroom).orderBy('created_at', 'desc').limit(15).onSnapshot({ includeMetadataChanges: true }, function (snapshot) {
      snapshot.docChanges().forEach(function (change) {
        if (change.type === 'added') {
          sms.push(change.doc.data());
        } else if (change.type === 'modified') {
          sms.push(change.doc.data());
        }
      });
      if (counter == 1) {
        counter = counter + 1;
        obj.chats = sms.reverse();
      } else {
        obj.chats = sms;
      }
      console.log(obj.chats);
      obj.content.scrollByPoint(0, 100000000, 300);
      obj.route.snapshot.queryParams.loader.dismiss();
    });
  }

  ionViewDidEnter() {
    this.getChats(this.messageRoom);
  }

  ngOnInit() {
  }

}
