import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FirebaseX } from '@ionic-native/firebase-x/ngx';
import { NavController } from '@ionic/angular';
import * as firebase from 'firebase';
import { ComponentService } from 'src/app/services/component.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  form: FormGroup;
  formSubmitted = false;
  db = firebase.default.firestore();
  userId = '';
  title = 'Login';

  constructor(private formBuilder: FormBuilder, private firebaseX: FirebaseX, private navCtrl: NavController, private componentService: ComponentService) { }

  onSignInClick() {
    this.formSubmitted = true;
    const obj = this;
    if (this.form.valid) {
      this.componentService.getLoader().then(
        (loader) => {
          loader.present().then(
            () => {
              this.firebaseX.getToken().then(
                (token) => {
                  this.db.collection('testUsers').where('number', '==', this.form.value.number).get().then(function (res) {
                    if (res.docChanges().length > 0) {
                      res.forEach(function (user) {
                        localStorage.setItem('userData', JSON.stringify(user.data()));
                        obj.db.collection('testUsers').doc(user.id).update({
                          token: token
                        });
                      });
                      obj.navCtrl.navigateRoot('/bottom-tab');
                      obj.componentService.getToast('Succesfully logged in.', 2000, 'top').then(
                        (toast) => {
                          toast.present();
                        }
                      );
                      loader.dismiss();
                    } else {
                      obj.componentService.getToast('Log in failed.', 2000, 'top').then(
                        (toast) => {
                          toast.present();
                        }
                      );
                      loader.dismiss();
                    }
                  });
                }
              );
            }
          );
        }
      );
    }
  }

  onSignUpClick() {
    this.formSubmitted = true;
    if (this.form.valid) {
      this.componentService.getLoader().then(
        (loader) => {
          loader.present().then(
            () => {
              this.firebaseX.getToken().then(
                (token) => {
                  this.db.collection('testUsers').doc(this.form.value.number).set({
                    token: token,
                    number: this.form.value.number,
                    password: this.form.value.password,
                    created_at: new Date().toISOString()
                  });
                  let user = {
                    token: token,
                    name: '',
                    picture: '',
                    number: this.form.value.number,
                    password: this.form.value.password,
                    created_at: new Date().toISOString()
                  };
                  localStorage.setItem('userData', JSON.stringify(user));
                  this.navCtrl.navigateRoot('/bottom-tab');
                  this.componentService.getToast('Succesfully registered.', 2000, 'top').then(
                    (toast) => {
                      toast.present();
                    }
                  );
                  loader.dismiss();
                }
              );
            }
          );
        }
      );
    }
  }

  onRegisterClick() {
    this.title = 'Register';
  }

  onLoginClick() {
    this.title = 'Login';
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      number: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

}
