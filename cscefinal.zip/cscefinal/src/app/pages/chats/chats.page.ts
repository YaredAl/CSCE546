import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import * as firebase from 'firebase';
import { ApiService } from 'src/app/services/api.service';
import { ComponentService } from 'src/app/services/component.service';

@Component({
  selector: 'app-chats',
  templateUrl: './chats.page.html',
  styleUrls: ['./chats.page.scss'],
})
export class ChatsPage implements OnInit {

  db = firebase.default.firestore();
  chatRooms: any[] = [];
  chatRoomsLoaded = false;
  userData = JSON.parse(localStorage.getItem('userData'));

  constructor(private componentService: ComponentService, private navCtrl: NavController, private apiService: ApiService) { }

  makeid(length) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }

  onAddClick() {
    this.componentService.getChatAlert('Enter Number').then(
      (alrt) => {
        alrt.present();
        alrt.onDidDismiss().then(
          (res: any) => {
            if (res.role == 'true') {
              if (res.data.values.number) {
                const obj = this;
                this.db.collection('testUsers').where('number', '==', res.data.values.number).get().then(function (response) {
                  if (response.docChanges().length > 0) {
                    response.forEach(function (doc) {
                      const name = 'chat_' + obj.makeid(5);
                      obj.db.collection('chatrooms').add({
                        chat_name: res.data.values.number,
                        chatroom: name,
                        created_by: obj.userData.number,
                        created_by_token: obj.userData.token,
                        created_with: res.data.values.number,
                        created_with_token: doc.data().token,
                        created_at: new Date().toISOString()
                      });
                      obj.chatRoomsLoaded = false;
                      obj.chatRooms = [];
                      obj.componentService.getLoader().then(
                        (loader) => {
                          loader.present().then(
                            () => {
                              obj.getChatRoom(loader);
                            }
                          );
                        }
                      );
                    });
                  } else {
                    obj.componentService.getToast('User not exist.', 2000, 'top').then(
                      (toast) => {
                        toast.present();
                      }
                    );
                  }
                });
              } else {
                this.componentService.getToast('Enter number.', 2000, 'top').then(
                  (toast) => {
                    toast.present();
                  }
                );
              }
            }
          }
        );
      }
    );
  }

  onChatClick(e) {
    this.componentService.getLoader().then(
      (loader) => {
        loader.present().then(
          () => {
            this.navCtrl.navigateForward('/chat', {
              queryParams: {
                data: e,
                loader: loader,
              }, animated: false
            });
          }
        );
      }
    );
  }

  getChatRoom(loader) {
    const obj = this;
    this.db.collection('chatrooms').where('created_by', '==', this.userData.number).get().then(function (res) {
      res.forEach(function (doc) {
        obj.chatRooms.push(doc.data());
      });
      obj.db.collection('chatrooms').where('created_with', '==', obj.userData.number).get().then(function (res) {
        res.forEach(function (doc) {
          obj.chatRooms.push(doc.data());
        });
      });
      obj.chatRoomsLoaded = true;
      loader.dismiss();
    });
  }

  ionViewDidEnter() {
    this.chatRoomsLoaded = false;
    this.chatRooms = [];
    this.componentService.getLoader().then(
      (loader) => {
        loader.present().then(
          () => {
            this.getChatRoom(loader);
          }
        );
      }
    );
  }

  ngOnInit() {
  }

}
