(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["groups-groups-module"],{

/***/ "56b7":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/groups/groups.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Groups</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-icon name=\"add-outline\" (click)=\"onAddClick()\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngIf=\"chatGroupsLoaded\">\n    <ion-card *ngFor=\"let cG of chatGroups\">\n      <ion-card-content (click)=\"onGroupClick(cG)\">\n        <ion-card-subtitle>{{cG.group_name}}</ion-card-subtitle>\n        <!-- <p *ngIf=\"cG.message\">{{(cG.senderId == appService.getUserProfile().userId) ? 'Me: ' +\n              cG.message : (!cG.displayName) ? cG.phoneNumber : cG.displayName + ': ' + cG.message}}</p>\n            <ion-card-title *ngIf=\"!cG.updated_at\">{{(appService.getDisplayDate(currentDate) ==\n              appService.getDisplayDate(cG.created_at)) ? 'Today ' +\n              appService.getTimeFormat(cG.created_at) :\n              appService.getDisplayDate(cG.created_at)}}</ion-card-title>\n            <ion-card-title *ngIf=\"cG.updated_at\">{{appService.getDisplayDate(currentDate) ==\n              appService.getDisplayDate(cG.updated_at) ? 'Today ' +\n              appService.getTimeFormat(cG.created_at) :\n              appService.getDisplayDate(cG.updated_at)}}</ion-card-title> -->\n      </ion-card-content>\n    </ion-card>\n  </div>\n\n  <ion-item *ngIf=\"chatGroups.length == 0 && chatGroupsLoaded\">\n    <p class=\"empty\">No Group Found</p>\n  </ion-item>\n\n</ion-content>");

/***/ }),

/***/ "OcId":
/*!*********************************************!*\
  !*** ./src/app/pages/groups/groups.page.ts ***!
  \*********************************************/
/*! exports provided: GroupsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroupsPage", function() { return GroupsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_groups_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./groups.page.html */ "56b7");
/* harmony import */ var _groups_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./groups.page.scss */ "Op3+");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "JZFu");
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/api.service */ "H+bZ");
/* harmony import */ var src_app_services_component_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/component.service */ "codd");








let GroupsPage = class GroupsPage {
    constructor(componentService, navCtrl, apiService) {
        this.componentService = componentService;
        this.navCtrl = navCtrl;
        this.apiService = apiService;
        this.db = firebase__WEBPACK_IMPORTED_MODULE_5__["default"].firestore();
        this.chatGroups = [];
        this.loadedChatGroups = [];
        this.chatGroupsLoaded = false;
        this.userData = JSON.parse(localStorage.getItem('userData'));
    }
    makeid(length) {
        let result = '';
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        const charactersLength = characters.length;
        for (let i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    }
    onAddClick() {
        this.componentService.getGroupAlert('Group Name').then((alrt) => {
            alrt.present();
            alrt.onDidDismiss().then((res) => {
                if (res.role == 'true') {
                    if (res.data.values.name) {
                        const name = 'group_' + this.makeid(5);
                        this.db.collection('groups').add({
                            group_name: res.data.values.name,
                            chatroom: name,
                            created_by: this.userData.number,
                            created_by_token: this.userData.token,
                            created_with: [],
                            created_at: new Date().toISOString()
                        });
                        this.chatGroupsLoaded = false;
                        this.chatGroups = [];
                        this.componentService.getLoader().then((loader) => {
                            loader.present().then(() => {
                                this.getChatGroups(loader);
                            });
                        });
                        this.componentService.getToast('Group created successfully.', 2000, 'top').then((toast) => {
                            toast.present();
                        });
                    }
                    else {
                        this.componentService.getToast('Enter group name.', 2000, 'top').then((toast) => {
                            toast.present();
                        });
                    }
                }
            });
        });
    }
    onGroupClick(e) {
        this.componentService.getLoader().then((loader) => {
            loader.present().then(() => {
                this.navCtrl.navigateForward('/chat', {
                    queryParams: {
                        from: 'groups',
                        data: e,
                        loader: loader,
                    }, animated: false
                });
            });
        });
    }
    getChatGroups(loader) {
        const obj = this;
        obj.db.collection('groups').get().then(function (res) {
            res.forEach(function (doc) {
                obj.chatGroups.push(doc.data());
            });
            obj.loadedChatGroups = obj.chatGroups;
            obj.chatGroupsLoaded = true;
            loader.dismiss();
        });
    }
    ionViewDidEnter() {
        this.chatGroupsLoaded = false;
        this.chatGroups = [];
        this.componentService.getLoader().then((loader) => {
            loader.present().then(() => {
                this.getChatGroups(loader);
            });
        });
    }
    ngOnInit() {
    }
};
GroupsPage.ctorParameters = () => [
    { type: src_app_services_component_service__WEBPACK_IMPORTED_MODULE_7__["ComponentService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: src_app_services_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"] }
];
GroupsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-groups',
        template: _raw_loader_groups_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_groups_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], GroupsPage);



/***/ }),

/***/ "Op3+":
/*!***********************************************!*\
  !*** ./src/app/pages/groups/groups.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJncm91cHMucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "ak9z":
/*!***********************************************!*\
  !*** ./src/app/pages/groups/groups.module.ts ***!
  \***********************************************/
/*! exports provided: GroupsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroupsPageModule", function() { return GroupsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _groups_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./groups-routing.module */ "jEu0");
/* harmony import */ var _groups_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./groups.page */ "OcId");







let GroupsPageModule = class GroupsPageModule {
};
GroupsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _groups_routing_module__WEBPACK_IMPORTED_MODULE_5__["GroupsPageRoutingModule"]
        ],
        declarations: [_groups_page__WEBPACK_IMPORTED_MODULE_6__["GroupsPage"]]
    })
], GroupsPageModule);



/***/ }),

/***/ "jEu0":
/*!*******************************************************!*\
  !*** ./src/app/pages/groups/groups-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: GroupsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroupsPageRoutingModule", function() { return GroupsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _groups_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./groups.page */ "OcId");




const routes = [
    {
        path: '',
        component: _groups_page__WEBPACK_IMPORTED_MODULE_3__["GroupsPage"]
    }
];
let GroupsPageRoutingModule = class GroupsPageRoutingModule {
};
GroupsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], GroupsPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=groups-groups-module.js.map