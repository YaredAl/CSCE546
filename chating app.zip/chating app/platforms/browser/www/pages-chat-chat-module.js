(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-chat-chat-module"],{

/***/ "0MZs":
/*!*******************************************!*\
  !*** ./src/app/pages/chat/chat.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".right .message {\n  justify-content: flex-end;\n}\n.right .message .date {\n  margin-left: 0;\n  text-align: right;\n}\n.message {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n  border: 1px solid #c3c3c3;\n  margin: 0px 0px 10px 0px;\n  padding: 10px;\n}\n.message .desc {\n  position: relative;\n  font-size: 20px;\n  width: calc(100% - 80px);\n}\n.message .date {\n  font-size: 12px;\n  color: #c3c3c3;\n  width: 100%;\n  margin: 10px 0px 0 44px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2NoYXQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0kseUJBQUE7QUFBUjtBQUVRO0VBQ0ksY0FBQTtFQUNBLGlCQUFBO0FBQVo7QUFLQTtFQUNJLGFBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLHdCQUFBO0VBQ0EsYUFBQTtBQUZKO0FBSUk7RUFDSSxrQkFBQTtFQUNBLGVBQUE7RUFDQSx3QkFBQTtBQUZSO0FBS0k7RUFDSSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7RUFDQSx1QkFBQTtBQUhSIiwiZmlsZSI6ImNoYXQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJpZ2h0IHtcbiAgICAubWVzc2FnZSB7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG5cbiAgICAgICAgLmRhdGUge1xuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDA7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLm1lc3NhZ2Uge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC13cmFwOiB3cmFwO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2MzYzNjMztcbiAgICBtYXJnaW46IDBweCAwcHggMTBweCAwcHg7XG4gICAgcGFkZGluZzogMTBweDtcblxuICAgIC5kZXNjIHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgIHdpZHRoOiBjYWxjKDEwMCUgLSA4MHB4KTtcbiAgICB9XG5cbiAgICAuZGF0ZSB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgY29sb3I6ICNjM2MzYzM7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBtYXJnaW46IDEwcHggMHB4IDAgNDRweDtcbiAgICB9XG59XG4iXX0= */");

/***/ }),

/***/ "EAAc":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/chat/chat.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button fill=\"clear\" (click)=\"onBackClick()\">\n        <ion-icon name=\"arrow-back-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\" *ngIf=\"route.snapshot.queryParams.from == 'groups'\">\n      <ion-icon name=\"add-outline\" (click)=\"onAddClick()\"></ion-icon>\n    </ion-buttons>\n    <ion-title>{{title}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content #scrollElement>\n  <div #contentArea [ngClass]=\"(userData.number == c.sender_id) ? 'right' : ''\" *ngFor=\"let c of chats\">\n    <div class=\"message\">\n      <div class=\"desc\">\n        {{c.message}}\n      </div>\n      <p class=\"date\">{{c.created_at}}</p>\n    </div>\n  </div>\n</ion-content>\n<ion-footer>\n  <input type=\"text\" (input)=\"onMessageField()\" [(ngModel)]=\"message\" placeholder=\"Enter your phone number\">\n  <ion-button fill=\"clear\" (click)=\"onMessage()\" (mousedown)=\"$event.preventDefault()\">\n    <ion-icon name=\"send-outline\"></ion-icon>\n  </ion-button>\n</ion-footer>");

/***/ }),

/***/ "EdD2":
/*!*******************************************!*\
  !*** ./src/app/pages/chat/chat.module.ts ***!
  \*******************************************/
/*! exports provided: ChatPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChatPageModule", function() { return ChatPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _chat_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./chat-routing.module */ "fp8f");
/* harmony import */ var _chat_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./chat.page */ "oflK");







let ChatPageModule = class ChatPageModule {
};
ChatPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _chat_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChatPageRoutingModule"]
        ],
        declarations: [_chat_page__WEBPACK_IMPORTED_MODULE_6__["ChatPage"]]
    })
], ChatPageModule);



/***/ }),

/***/ "fp8f":
/*!***************************************************!*\
  !*** ./src/app/pages/chat/chat-routing.module.ts ***!
  \***************************************************/
/*! exports provided: ChatPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChatPageRoutingModule", function() { return ChatPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _chat_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./chat.page */ "oflK");




const routes = [
    {
        path: '',
        component: _chat_page__WEBPACK_IMPORTED_MODULE_3__["ChatPage"]
    }
];
let ChatPageRoutingModule = class ChatPageRoutingModule {
};
ChatPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ChatPageRoutingModule);



/***/ }),

/***/ "oflK":
/*!*****************************************!*\
  !*** ./src/app/pages/chat/chat.page.ts ***!
  \*****************************************/
/*! exports provided: ChatPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChatPage", function() { return ChatPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_chat_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./chat.page.html */ "EAAc");
/* harmony import */ var _chat_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./chat.page.scss */ "0MZs");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! firebase */ "JZFu");
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/api.service */ "H+bZ");
/* harmony import */ var src_app_services_component_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/component.service */ "codd");









let ChatPage = class ChatPage {
    constructor(route, componentService, apiService, location) {
        this.route = route;
        this.componentService = componentService;
        this.apiService = apiService;
        this.location = location;
        this.chats = [];
        this.db = firebase__WEBPACK_IMPORTED_MODULE_6__["default"].firestore();
        this.messageRoom = '';
        this.refMessages = '';
        this.message = '';
        this.title = '';
        this.msgField = false;
        this.userData = JSON.parse(localStorage.getItem('userData'));
        this.recievers = [];
        this.messageRoom = route.snapshot.queryParams.data.chatroom;
        if (route.snapshot.queryParams.data.group_name) {
            this.title = route.snapshot.queryParams.data.group_name;
            this.recievers = route.snapshot.queryParams.data.created_with;
        }
        else {
            this.title = route.snapshot.queryParams.data.chat_name;
        }
        this.refMessages = this.db.collection('messages').doc(this.messageRoom);
    }
    onBackClick() {
        this.location.back();
    }
    sendNotification(token, title, message, from) {
        this.apiService.sendNotification(token, title, message, from).subscribe((res) => { }, (err) => { });
    }
    onAddClick() {
        this.componentService.getUserAlert('Enter Number').then((alrt) => {
            alrt.present();
            alrt.onDidDismiss().then((res) => {
                if (res.role == 'true') {
                    if (res.data.values.number) {
                        const obj = this;
                        this.db.collection('testUsers').where('number', '==', res.data.values.number).get().then(function (response) {
                            if (response.docChanges().length > 0) {
                                response.forEach(function (doc) {
                                    obj.componentService.getLoader().then((loader) => {
                                        loader.present().then(() => {
                                            let id;
                                            let users = [{ number: doc.data().number, token: doc.data().token }];
                                            obj.db.collection('groups').where('chatroom', '==', obj.messageRoom).get().then(function (res) {
                                                res.forEach(function (doc) {
                                                    id = doc.id;
                                                    users.push(...doc.data().created_with);
                                                });
                                                obj.recievers = users;
                                                obj.db.collection('groups').doc(id).set({
                                                    created_with: users
                                                }, { merge: true });
                                                obj.componentService.getToast('User added.', 2000, 'top').then((toast) => {
                                                    toast.present();
                                                });
                                                loader.dismiss();
                                            });
                                        });
                                    });
                                });
                            }
                            else {
                                obj.componentService.getToast('User not exist.', 2000, 'top').then((toast) => {
                                    toast.present();
                                });
                            }
                        });
                    }
                    else {
                        this.componentService.getToast('Enter number.', 2000, 'top').then((toast) => {
                            toast.present();
                        });
                    }
                }
            });
        });
    }
    onMessage() {
        if (this.message.trim() != '') {
            this.refMessages.collection(this.messageRoom).add({
                message: this.message,
                sender_id: this.userData.number,
                created_at: new Date().toISOString()
            });
            if (this.recievers.length > 0) {
                this.recievers.forEach((user) => {
                    this.sendNotification(user.token, this.userData.number, this.message, this.userData.number);
                });
            }
            else {
                this.sendNotification(this.route.snapshot.queryParams.data.created_with_token, this.userData.number, this.message, this.userData.number);
            }
            this.msgField = false;
            this.message = '';
            this.content.scrollByPoint(0, 100000000, 300);
        }
        else {
            this.componentService.getToast('Cannot send empty message.', 2000, 'top').then((toast) => {
                toast.present();
            });
        }
    }
    onMessageField() {
        if (this.message.trim() == '') {
            this.msgField = false;
        }
        else {
            this.msgField = true;
        }
    }
    getChats(chatroom) {
        const obj = this;
        let sms = [];
        let counter = 1;
        obj.refMessages.collection(chatroom).orderBy('created_at', 'desc').limit(15).onSnapshot({ includeMetadataChanges: true }, function (snapshot) {
            snapshot.docChanges().forEach(function (change) {
                if (change.type === 'added') {
                    sms.push(change.doc.data());
                }
                else if (change.type === 'modified') {
                    sms.push(change.doc.data());
                }
            });
            if (counter == 1) {
                counter = counter + 1;
                obj.chats = sms.reverse();
            }
            else {
                obj.chats = sms;
            }
            console.log(obj.chats);
            obj.content.scrollByPoint(0, 100000000, 300);
            obj.route.snapshot.queryParams.loader.dismiss();
        });
    }
    ionViewDidEnter() {
        this.getChats(this.messageRoom);
    }
    ngOnInit() {
    }
};
ChatPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: src_app_services_component_service__WEBPACK_IMPORTED_MODULE_8__["ComponentService"] },
    { type: src_app_services_api_service__WEBPACK_IMPORTED_MODULE_7__["ApiService"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"] }
];
ChatPage.propDecorators = {
    content: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"], args: ['scrollElement', { static: false },] }]
};
ChatPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-chat',
        template: _raw_loader_chat_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_chat_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ChatPage);



/***/ })

}]);
//# sourceMappingURL=pages-chat-chat-module.js.map