(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-login-login-module"],{

/***/ "F4UR":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.module.ts ***!
  \*********************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login-routing.module */ "aTZN");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "bP1B");







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _login_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginPageRoutingModule"]
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })
], LoginPageModule);



/***/ }),

/***/ "H+1c":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsb2dpbi5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "TuYN":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>{{title}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <form [formGroup]=\"form\">\n    <ion-item>\n      <ion-label>PHONE NUMBER</ion-label>\n      <input type=\"tel\" formControlName=\"number\" placeholder=\"Enter your phone number\">\n    </ion-item>\n    <div *ngIf=\"formSubmitted && form.controls.number.errors\">\n      Enter your phone number.\n    </div>\n    <ion-item>\n      <ion-label>PASSWORD</ion-label>\n      <input type=\"password\" formControlName=\"password\" placeholder=\"Enter your password\">\n    </ion-item>\n    <div *ngIf=\"formSubmitted && form.controls.password.errors\">\n      Enter your phone password.\n    </div>\n  </form>\n\n  <p *ngIf=\"title == 'Login'\">Don't have an account? <span (click)=\"onRegisterClick()\">Register!</span></p>\n  <p *ngIf=\"title == 'Register'\">Have an account? <span (click)=\"onLoginClick()\">Login!</span></p>\n</ion-content>\n\n<ion-footer>\n  <ion-button *ngIf=\"title == 'Login'\" expand=\"block\" fill=\"outline\" (click)=\"onSignInClick()\">SIGN IN</ion-button>\n  <ion-button *ngIf=\"title == 'Register'\" expand=\"block\" fill=\"outline\" (click)=\"onSignUpClick()\">SIGN UP</ion-button>\n</ion-footer>");

/***/ }),

/***/ "aTZN":
/*!*****************************************************!*\
  !*** ./src/app/pages/login/login-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: LoginPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function() { return LoginPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.page */ "bP1B");




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ "bP1B":
/*!*******************************************!*\
  !*** ./src/app/pages/login/login.page.ts ***!
  \*******************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./login.page.html */ "TuYN");
/* harmony import */ var _login_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login.page.scss */ "H+1c");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_native_firebase_x_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/firebase-x/ngx */ "E9qw");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! firebase */ "JZFu");
/* harmony import */ var src_app_services_component_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/component.service */ "codd");









let LoginPage = class LoginPage {
    constructor(formBuilder, firebaseX, navCtrl, componentService) {
        this.formBuilder = formBuilder;
        this.firebaseX = firebaseX;
        this.navCtrl = navCtrl;
        this.componentService = componentService;
        this.formSubmitted = false;
        this.db = firebase__WEBPACK_IMPORTED_MODULE_7__["default"].firestore();
        this.userId = '';
        this.title = 'Login';
    }
    onSignInClick() {
        this.formSubmitted = true;
        const obj = this;
        if (this.form.valid) {
            this.componentService.getLoader().then((loader) => {
                loader.present().then(() => {
                    this.firebaseX.getToken().then((token) => {
                        this.db.collection('testUsers').where('number', '==', this.form.value.number).get().then(function (res) {
                            if (res.docChanges().length > 0) {
                                res.forEach(function (user) {
                                    localStorage.setItem('userData', JSON.stringify(user.data()));
                                    obj.db.collection('testUsers').doc(user.id).update({
                                        token: token
                                    });
                                });
                                obj.navCtrl.navigateRoot('/bottom-tab');
                                obj.componentService.getToast('Succesfully logged in.', 2000, 'top').then((toast) => {
                                    toast.present();
                                });
                                loader.dismiss();
                            }
                            else {
                                obj.componentService.getToast('Log in failed.', 2000, 'top').then((toast) => {
                                    toast.present();
                                });
                                loader.dismiss();
                            }
                        });
                    });
                });
            });
        }
    }
    onSignUpClick() {
        this.formSubmitted = true;
        if (this.form.valid) {
            this.componentService.getLoader().then((loader) => {
                loader.present().then(() => {
                    this.firebaseX.getToken().then((token) => {
                        this.db.collection('testUsers').doc(this.form.value.number).set({
                            token: token,
                            number: this.form.value.number,
                            password: this.form.value.password,
                            created_at: new Date().toISOString()
                        });
                        let user = {
                            token: token,
                            name: '',
                            picture: '',
                            number: this.form.value.number,
                            password: this.form.value.password,
                            created_at: new Date().toISOString()
                        };
                        localStorage.setItem('userData', JSON.stringify(user));
                        this.navCtrl.navigateRoot('/bottom-tab');
                        this.componentService.getToast('Succesfully registered.', 2000, 'top').then((toast) => {
                            toast.present();
                        });
                        loader.dismiss();
                    });
                });
            });
        }
    }
    onRegisterClick() {
        this.title = 'Register';
    }
    onLoginClick() {
        this.title = 'Login';
    }
    ngOnInit() {
        this.form = this.formBuilder.group({
            number: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
    }
};
LoginPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _ionic_native_firebase_x_ngx__WEBPACK_IMPORTED_MODULE_5__["FirebaseX"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: src_app_services_component_service__WEBPACK_IMPORTED_MODULE_8__["ComponentService"] }
];
LoginPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-login',
        template: _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_login_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], LoginPage);



/***/ })

}]);
//# sourceMappingURL=pages-login-login-module.js.map