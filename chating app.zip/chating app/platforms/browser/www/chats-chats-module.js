(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["chats-chats-module"],{

/***/ "EJ+t":
/*!*****************************************************!*\
  !*** ./src/app/pages/chats/chats-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: ChatsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChatsPageRoutingModule", function() { return ChatsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _chats_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./chats.page */ "ZJfK");




const routes = [
    {
        path: '',
        component: _chats_page__WEBPACK_IMPORTED_MODULE_3__["ChatsPage"]
    }
];
let ChatsPageRoutingModule = class ChatsPageRoutingModule {
};
ChatsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ChatsPageRoutingModule);



/***/ }),

/***/ "Tuwx":
/*!*********************************************!*\
  !*** ./src/app/pages/chats/chats.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGF0cy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "UTXh":
/*!*********************************************!*\
  !*** ./src/app/pages/chats/chats.module.ts ***!
  \*********************************************/
/*! exports provided: ChatsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChatsPageModule", function() { return ChatsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _chats_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./chats-routing.module */ "EJ+t");
/* harmony import */ var _chats_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./chats.page */ "ZJfK");







let ChatsPageModule = class ChatsPageModule {
};
ChatsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _chats_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChatsPageRoutingModule"]
        ],
        declarations: [_chats_page__WEBPACK_IMPORTED_MODULE_6__["ChatsPage"]]
    })
], ChatsPageModule);



/***/ }),

/***/ "ZJfK":
/*!*******************************************!*\
  !*** ./src/app/pages/chats/chats.page.ts ***!
  \*******************************************/
/*! exports provided: ChatsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChatsPage", function() { return ChatsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_chats_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./chats.page.html */ "is+8");
/* harmony import */ var _chats_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./chats.page.scss */ "Tuwx");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "JZFu");
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/api.service */ "H+bZ");
/* harmony import */ var src_app_services_component_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/component.service */ "codd");








let ChatsPage = class ChatsPage {
    constructor(componentService, navCtrl, apiService) {
        this.componentService = componentService;
        this.navCtrl = navCtrl;
        this.apiService = apiService;
        this.db = firebase__WEBPACK_IMPORTED_MODULE_5__["default"].firestore();
        this.chatRooms = [];
        this.chatRoomsLoaded = false;
        this.userData = JSON.parse(localStorage.getItem('userData'));
    }
    makeid(length) {
        let result = '';
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        const charactersLength = characters.length;
        for (let i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    }
    onAddClick() {
        this.componentService.getChatAlert('Enter Number').then((alrt) => {
            alrt.present();
            alrt.onDidDismiss().then((res) => {
                if (res.role == 'true') {
                    if (res.data.values.number) {
                        const obj = this;
                        this.db.collection('testUsers').where('number', '==', res.data.values.number).get().then(function (response) {
                            if (response.docChanges().length > 0) {
                                response.forEach(function (doc) {
                                    const name = 'chat_' + obj.makeid(5);
                                    obj.db.collection('chatrooms').add({
                                        chat_name: res.data.values.number,
                                        chatroom: name,
                                        created_by: obj.userData.number,
                                        created_by_token: obj.userData.token,
                                        created_with: res.data.values.number,
                                        created_with_token: doc.data().token,
                                        created_at: new Date().toISOString()
                                    });
                                    obj.chatRoomsLoaded = false;
                                    obj.chatRooms = [];
                                    obj.componentService.getLoader().then((loader) => {
                                        loader.present().then(() => {
                                            obj.getChatRoom(loader);
                                        });
                                    });
                                });
                            }
                            else {
                                obj.componentService.getToast('User not exist.', 2000, 'top').then((toast) => {
                                    toast.present();
                                });
                            }
                        });
                    }
                    else {
                        this.componentService.getToast('Enter number.', 2000, 'top').then((toast) => {
                            toast.present();
                        });
                    }
                }
            });
        });
    }
    onChatClick(e) {
        this.componentService.getLoader().then((loader) => {
            loader.present().then(() => {
                this.navCtrl.navigateForward('/chat', {
                    queryParams: {
                        data: e,
                        loader: loader,
                    }, animated: false
                });
            });
        });
    }
    getChatRoom(loader) {
        const obj = this;
        this.db.collection('chatrooms').where('created_by', '==', this.userData.number).get().then(function (res) {
            res.forEach(function (doc) {
                obj.chatRooms.push(doc.data());
            });
            obj.db.collection('chatrooms').where('created_with', '==', obj.userData.number).get().then(function (res) {
                res.forEach(function (doc) {
                    obj.chatRooms.push(doc.data());
                });
            });
            obj.chatRoomsLoaded = true;
            loader.dismiss();
        });
    }
    ionViewDidEnter() {
        this.chatRoomsLoaded = false;
        this.chatRooms = [];
        this.componentService.getLoader().then((loader) => {
            loader.present().then(() => {
                this.getChatRoom(loader);
            });
        });
    }
    ngOnInit() {
    }
};
ChatsPage.ctorParameters = () => [
    { type: src_app_services_component_service__WEBPACK_IMPORTED_MODULE_7__["ComponentService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: src_app_services_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"] }
];
ChatsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-chats',
        template: _raw_loader_chats_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_chats_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ChatsPage);



/***/ }),

/***/ "is+8":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/chats/chats.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Chats</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-icon name=\"add-outline\" (click)=\"onAddClick()\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngIf=\"chatRoomsLoaded\">\n    <ion-card *ngFor=\"let c of chatRooms\">\n      <ion-card-content (click)=\"onChatClick(c)\">\n        <ion-card-subtitle>{{c.chat_name}}</ion-card-subtitle>\n      </ion-card-content>\n    </ion-card>\n  </div>\n\n  <ion-item *ngIf=\"chatRooms.length == 0 && chatRoomsLoaded\">\n    <p>No chat found start chat by clicking on ( + ) icon.</p>\n  </ion-item>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=chats-chats-module.js.map