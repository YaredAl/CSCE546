(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-profile-module"],{

/***/ "723k":
/*!*************************************************!*\
  !*** ./src/app/pages/profile/profile.module.ts ***!
  \*************************************************/
/*! exports provided: ProfilePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function() { return ProfilePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./profile-routing.module */ "x0XS");
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./profile.page */ "uxLX");







let ProfilePageModule = class ProfilePageModule {
};
ProfilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProfilePageRoutingModule"]
        ],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]]
    })
], ProfilePageModule);



/***/ }),

/***/ "EGjV":
/*!*************************************************!*\
  !*** ./src/app/pages/profile/profile.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".logo {\n  position: relative;\n}\n.logo .img {\n  width: 100px;\n  height: 100px;\n  border-radius: 100%;\n  overflow: hidden;\n  margin: auto;\n  margin-bottom: 10px;\n  display: flex;\n  border: 1px solid #b2b1b0;\n}\n.edit {\n  position: absolute;\n  display: inline;\n  top: 0px;\n  right: 0;\n  width: 30px;\n  height: 30px;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: #2cbea5;\n}\n.edit img {\n  width: 15px;\n}\n.edit input {\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 100%;\n  height: 100%;\n  opacity: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7QUFDSjtBQUNJO0VBQ0ksWUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLHlCQUFBO0FBQ1I7QUFHQTtFQUNJLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLFFBQUE7RUFDQSxRQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFBSjtBQUVJO0VBQ0ksV0FBQTtBQUFSO0FBR0k7RUFDSSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxNQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0FBRFIiLCJmaWxlIjoicHJvZmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubG9nbyB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gICAgLmltZyB7XG4gICAgICAgIHdpZHRoOiAxMDBweDtcbiAgICAgICAgaGVpZ2h0OiAxMDBweDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgbWFyZ2luOiBhdXRvO1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjYjJiMWIwO1xuICAgIH1cbn1cblxuLmVkaXQge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBkaXNwbGF5OiBpbmxpbmU7XG4gICAgdG9wOiAwcHg7XG4gICAgcmlnaHQ6IDA7XG4gICAgd2lkdGg6IDMwcHg7XG4gICAgaGVpZ2h0OiAzMHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYmFja2dyb3VuZDogIzJjYmVhNTtcblxuICAgIGltZyB7XG4gICAgICAgIHdpZHRoOiAxNXB4O1xuICAgIH1cblxuICAgIGlucHV0IHtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICBsZWZ0OiAwO1xuICAgICAgICB0b3A6IDA7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgIG9wYWNpdHk6IDA7XG4gICAgfVxufVxuIl19 */");

/***/ }),

/***/ "VVTS":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/profile/profile.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Profile</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form [formGroup]=\"profileForm\" (keyup.enter)=\"onSubmitClick()\">\n    <ion-item>\n      <div class=\"logo\">\n        <div class=\"img\">\n          <img src=\"{{picture}}\" alt=\"\">\n        </div>\n        <h6 class=\"edit\">\n          <ion-icon name=\"pencil-outline\" (click)=\"onImage()\"></ion-icon>\n        </h6>\n      </div>\n    </ion-item>\n    <ion-item>\n      <div class=\"wrap-item\">\n        <ion-label>NAME</ion-label>\n        <input type=\"text\" formControlName=\"name\" placeholder=\"Enter your name\">\n        <div *ngIf=\"profileFormSubmitted && profileForm.controls.name.errors\" class=\"error-msg\">\n          Enter your name.\n        </div>\n      </div>\n    </ion-item>\n    <ion-item>\n      <div class=\"wrap-item\">\n        <ion-label>NUMBER</ion-label>\n        <input type=\"text\" disabled formControlName=\"number\" placeholder=\"Enter your status\">\n      </div>\n    </ion-item>\n  </form>\n</ion-content>\n\n<ion-footer>\n  <ion-button fill=\"outline\" (click)=\"onSubmitClick()\">UPDATE</ion-button>\n  <ion-button fill=\"outline\" (click)=\"onLogOutClick()\">LOG OUT</ion-button>\n</ion-footer>");

/***/ }),

/***/ "uxLX":
/*!***********************************************!*\
  !*** ./src/app/pages/profile/profile.page.ts ***!
  \***********************************************/
/*! exports provided: ProfilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePage", function() { return ProfilePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_profile_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./profile.page.html */ "VVTS");
/* harmony import */ var _profile_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./profile.page.scss */ "EGjV");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "JZFu");
/* harmony import */ var src_app_services_component_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/component.service */ "codd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "a/9d");









let ProfilePage = class ProfilePage {
    constructor(formBuilder, componentService, actionSheetController, camera, navCtrl) {
        this.formBuilder = formBuilder;
        this.componentService = componentService;
        this.actionSheetController = actionSheetController;
        this.camera = camera;
        this.navCtrl = navCtrl;
        this.profileFormSubmitted = false;
        this.db = firebase__WEBPACK_IMPORTED_MODULE_5__["default"].firestore();
        this.picture = '';
        this.userData = JSON.parse(localStorage.getItem('userData'));
        this.picture = this.userData.picture;
    }
    getImage(type, from) {
        if (from == 'gallery') {
            var options = {
                quality: 100,
                allowEdit: true,
                targetWidth: 146,
                targetHeight: 136,
                saveToPhotoAlbum: false,
                destinationType: this.camera.DestinationType.DATA_URL,
                sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
                encodingType: this.camera.EncodingType.JPEG,
            };
        }
        else {
            var options = {
                quality: 100,
                allowEdit: true,
                targetWidth: 146,
                targetHeight: 136,
                saveToPhotoAlbum: false,
                destinationType: this.camera.DestinationType.DATA_URL,
                encodingType: this.camera.EncodingType.JPEG,
                mediaType: this.camera.MediaType.PICTURE
            };
        }
        this.camera.getPicture(options).then((imageData) => {
            const image = 'data:image/jpeg;base64,' + imageData;
            this.picture = image;
            this.image = image;
        }, (err) => {
            console.log(err);
        });
    }
    onImage() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const sheet = yield this.actionSheetController.create({
                header: 'Select Option',
                buttons: [{
                        text: 'Camera',
                        icon: 'camera',
                        handler: () => {
                            this.getImage(this.camera.PictureSourceType.CAMERA, 'camera');
                        }
                    }, {
                        text: 'Gallery',
                        icon: 'images',
                        handler: () => {
                            this.getImage(this.camera.PictureSourceType.PHOTOLIBRARY, 'gallery');
                        }
                    }, {
                        text: 'Cancel',
                        icon: 'close',
                        role: 'cancel',
                        handler: () => {
                        }
                    }]
            });
            return sheet.present();
        });
    }
    onPicChange(event) {
        const type = event.target.files[0].type.toString();
        if (type.search('image') === 0) {
            this.picture = 'image';
            if (event.target.files && event.target.files[0]) {
                const reader = new FileReader();
                reader.readAsDataURL(event.target.files[0]);
                reader.onload = (ev) => {
                    this.picture = ev.target.result;
                };
            }
        }
        this.image = event.target.files[0];
    }
    onSubmitClick() {
        this.profileFormSubmitted = true;
        if (this.profileForm.valid) {
            this.componentService.getLoader().then((loader) => {
                loader.present().then(() => {
                    if (this.image) {
                        const obj = this;
                        const fileName = this.userData.number;
                        const fileRef = firebase__WEBPACK_IMPORTED_MODULE_5__["default"].storage().ref('images/' + fileName);
                        const uploadTask = fileRef.putString(this.image);
                        return new Promise((resolve, reject) => {
                            uploadTask.on('state_changed', snapshot => {
                            }, error => {
                                reject(error);
                            }, () => {
                                uploadTask.snapshot.ref.getDownloadURL().then(function (downloadURL) {
                                    obj.db.collection('testUsers').where('number', '==', this.userData.number).get().then(function (res) {
                                        res.forEach(function (user) {
                                            obj.db.collection('testUsers').doc(user.id).update({
                                                name: obj.profileForm.value.name,
                                                picture: downloadURL,
                                                updated_at: new Date().toISOString()
                                            });
                                        });
                                        let user = {
                                            name: obj.profileForm.value.name,
                                            picture: downloadURL,
                                        };
                                        localStorage.setItem('userData', JSON.stringify(user));
                                    });
                                    resolve({ fileName, downloadURL });
                                    obj.componentService.getToast('Profile updated successfully.', 2000, 'top').then((toast) => {
                                        toast.present();
                                    });
                                    loader.dismiss();
                                });
                            });
                        });
                    }
                    else {
                        const obj = this;
                        this.db.collection('testUsers').where('number', '==', this.userData.number).get().then(function (res) {
                            res.forEach(function (user) {
                                obj.db.collection('testUsers').doc(user.id).update({
                                    name: obj.profileForm.value.name,
                                    updated_at: new Date().toISOString()
                                });
                            });
                        });
                        let user = {
                            name: obj.profileForm.value.name,
                        };
                        localStorage.setItem('userData', JSON.stringify(user));
                        this.componentService.getToast('Profile updated successfully.', 2000, 'top').then((toast) => {
                            toast.present();
                        });
                        loader.dismiss();
                    }
                });
            });
        }
    }
    onLogOutClick() {
        localStorage.clear();
        this.navCtrl.navigateRoot('/login');
    }
    ionViewDidEnter() {
        this.profileForm = this.formBuilder.group({
            name: [this.userData.name, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            number: [this.userData.number],
        });
    }
    ngOnInit() {
        this.profileForm = this.formBuilder.group({
            name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            number: ['']
        });
    }
};
ProfilePage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: src_app_services_component_service__WEBPACK_IMPORTED_MODULE_6__["ComponentService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ActionSheetController"] },
    { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_8__["Camera"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavController"] }
];
ProfilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-profile',
        template: _raw_loader_profile_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_profile_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ProfilePage);



/***/ }),

/***/ "x0XS":
/*!*********************************************************!*\
  !*** ./src/app/pages/profile/profile-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: ProfilePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePageRoutingModule", function() { return ProfilePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./profile.page */ "uxLX");




const routes = [
    {
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_3__["ProfilePage"]
    }
];
let ProfilePageRoutingModule = class ProfilePageRoutingModule {
};
ProfilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ProfilePageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=profile-profile-module.js.map