import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import * as firebase from 'firebase';
import { ApiService } from 'src/app/services/api.service';
import { ComponentService } from 'src/app/services/component.service';

@Component({
  selector: 'app-groups',
  templateUrl: './groups.page.html',
  styleUrls: ['./groups.page.scss'],
})
export class GroupsPage implements OnInit {

  db = firebase.default.firestore();
  chatGroups: any[] = [];
  loadedChatGroups: any[] = [];
  chatGroupsLoaded = false;
  userData = JSON.parse(localStorage.getItem('userData'));

  constructor(private componentService: ComponentService, private navCtrl: NavController, private apiService: ApiService) { }

  makeid(length) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }

  onAddClick() {
    this.componentService.getGroupAlert('Group Name').then(
      (alrt) => {
        alrt.present();
        alrt.onDidDismiss().then(
          (res: any) => {
            if (res.role == 'true') {
              if (res.data.values.name) {
                const name = 'group_' + this.makeid(5);
                this.db.collection('groups').add({
                  group_name: res.data.values.name,
                  chatroom: name,
                  created_by: this.userData.number,
                  created_by_token: this.userData.token,
                  created_with: [],
                  created_at: new Date().toISOString()
                });
                this.chatGroupsLoaded = false;
                this.chatGroups = []
                this.componentService.getLoader().then(
                  (loader) => {
                    loader.present().then(
                      () => {
                        this.getChatGroups(loader);
                      }
                    );
                  }
                );
                this.componentService.getToast('Group created successfully.', 2000, 'top').then(
                  (toast) => {
                    toast.present();
                  }
                );
              } else {
                this.componentService.getToast('Enter group name.', 2000, 'top').then(
                  (toast) => {
                    toast.present();
                  }
                );
              }
            }
          }
        );
      }
    );
  }

  onGroupClick(e) {
    this.componentService.getLoader().then(
      (loader) => {
        loader.present().then(
          () => {
            this.navCtrl.navigateForward('/chat', {
              queryParams: {
                from: 'groups',
                data: e,
                loader: loader,
              }, animated: false
            });
          }
        );
      }
    );
  }

  getChatGroups(loader) {
    const obj = this;
    obj.db.collection('groups').get().then(function (res) {
      res.forEach(function (doc) {
        obj.chatGroups.push(doc.data());
      });
      obj.loadedChatGroups = obj.chatGroups;
      obj.chatGroupsLoaded = true;
      loader.dismiss();
    });
  }

  ionViewDidEnter() {
    this.chatGroupsLoaded = false;
    this.chatGroups = []
    this.componentService.getLoader().then(
      (loader) => {
        loader.present().then(
          () => {
            this.getChatGroups(loader);
          }
        );
      }
    );
  }

  ngOnInit() {
  }

}
