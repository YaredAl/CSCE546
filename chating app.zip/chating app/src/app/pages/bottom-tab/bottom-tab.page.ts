import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bottom-tab',
  templateUrl: './bottom-tab.page.html',
  styleUrls: ['./bottom-tab.page.scss'],
})
export class BottomTabPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
