import { Injectable } from '@angular/core';
import { ComponentService } from './component.service';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, map, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  token = 'AAAA_pQQMAw:APA91bFx3h327x01Uy-6bYztFLxNMmtoXMQEjoxjUAY-97tjDuo7FODNb78zqP1RO535HHgQKZC1OSY5Bmy6ht1fmu9uN5v4qQVtVT1F58VOohRGc_5ewHYD8GOiAQ4xrT_d5MC_8ji4';

  constructor(private http: HttpClient, private componentService: ComponentService) { }

  public sendNotification(to: any, title: any, notification: any, from: any) {
    const url = 'https://fcm.googleapis.com/fcm/send';
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: 'key=' + this.token,
      })
    };
    const body = {
      'to': to,
      'from': from,
      'notification': {
        'title': title,
        'body': notification,
      },
    }
    return this.http.post(url, body, httpOptions).pipe(
      map(
        (response) => {
          return response;
        }
      ),
      retry(0),
      catchError(
        (error: HttpErrorResponse) => {
          throw this.handleError(error);
        }
      )
    );
  }

  public handleError(error: HttpErrorResponse) {
    console.log(error);
    if (error.error instanceof ErrorEvent) { } else if (error) {
      this.componentService.getToast('Something went wrong.', 3000, 'top').then(
        (toast) => {
          toast.present();
        }
      );
    }
  }
}
