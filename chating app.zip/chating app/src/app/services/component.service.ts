import { Injectable } from '@angular/core';
import { AlertController, LoadingController, ToastController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class ComponentService {

  constructor(private toastCtrl: ToastController, private loadingCtrl: LoadingController, private alertController: AlertController) { }

  getToast(msg: any, dur: any, pos: any, css = '') {
    return this.toastCtrl.create({
      message: msg,
      duration: dur,
      position: pos,
      cssClass: css,
    });
  }

  getLoader(msg = '', css = '') {
    return this.loadingCtrl.create({
      spinner: 'bubbles',
      message: msg,
      cssClass: css,
      backdropDismiss: false
    });
  }

  getChatAlert(title: any, css?: any) {
    const alert = this.alertController.create({
      header: title,
      backdropDismiss: false,
      inputs: [
        {
          name: 'number',
          placeholder: 'Enter Number',
        },
      ],
      cssClass: css,
      buttons: [
        {
          text: 'Create',
          role: 'true',
          handler: () => {
            this.alertController.dismiss();
          }
        },
        {
          text: 'Cancel',
          role: 'false',
          handler: () => {
            this.alertController.dismiss();
          }
        }
      ]
    });
    return alert;
  }

  getGroupAlert(title: any, css?: any) {
    const alert = this.alertController.create({
      header: title,
      backdropDismiss: false,
      inputs: [
        {
          name: 'name',
          placeholder: 'Enter Group Name',
        },
      ],
      cssClass: css,
      buttons: [
        {
          text: 'Create',
          role: 'true',
          handler: () => {
            this.alertController.dismiss();
          }
        },
        {
          text: 'Cancel',
          role: 'false',
          handler: () => {
            this.alertController.dismiss();
          }
        }
      ]
    });
    return alert;
  }

  getUserAlert(title: any, css?: any) {
    const alert = this.alertController.create({
      header: title,
      backdropDismiss: false,
      inputs: [
        {
          name: 'number',
          placeholder: 'Enter number',
        },
      ],
      cssClass: css,
      buttons: [
        {
          text: 'Add',
          role: 'true',
          handler: () => {
            this.alertController.dismiss();
          }
        },
        {
          text: 'Cancel',
          role: 'false',
          handler: () => {
            this.alertController.dismiss();
          }
        }
      ]
    });
    return alert;
  }

}
