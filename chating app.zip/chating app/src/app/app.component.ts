import { Component } from '@angular/core';
import * as firebase from 'firebase';
import { environment } from 'src/environments/environment';
import { FirebaseX } from '@ionic-native/firebase-x/ngx';
import { NavController, Platform } from '@ionic/angular';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor(private platform: Platform, private firebaseX: FirebaseX, private navCtrl: NavController) {
    firebase.default.initializeApp(environment.firebaseConfig);
    if (localStorage.getItem('userData')) {
      this.navCtrl.navigateRoot('/bottom-tab');
    } else {
      this.navCtrl.navigateRoot('/login');
    }
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      // this.statusBar.styleDefault();
      // this.statusBar.overlaysWebView(true);
      // this.statusBar.backgroundColorByHexString('#1EBEA5');
      // this.splashScreen.hide();
      if (this.platform.is('ios')) {
        this.firebaseX.grantPermission().then(
          (val: any) => {
            console.log(val);
            console.log('permission granted!');
          }, (err: any) => {
            console.log(err);
          }
        );
      }

      this.firebaseX.onMessageReceived().subscribe(
        (res: any) => {
          console.log(res);
        }, (err: any) => {
          console.log(err);
        }
      );

    });
  }
}
