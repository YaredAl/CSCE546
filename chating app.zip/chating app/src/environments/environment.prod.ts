export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyCF9m7SpXeBwF3ykeaogO77mRWqqXJhxt8",
    authDomain: "finalprojecr-857f9.firebaseapp.com",
    projectId: "finalprojecr-857f9",
    storageBucket: "finalprojecr-857f9.appspot.com",
    messagingSenderId: "817112342699",
    appId: "1:817112342699:web:9ac61d1d21ae5701ce97ee",
    measurementId: "G-EC6VGJRTW2"
  },
};
